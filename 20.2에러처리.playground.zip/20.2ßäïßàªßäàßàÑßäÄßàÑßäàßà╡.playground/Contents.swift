import UIKit

//에러처리를 하는 방법
//try/ try? try!


enum HeightError: Error {
    case maxHeight
    case minHeight
}




func checkingHeight(height: Int) throws -> Bool {
    
    if height > 190 {
        throw HeightError.maxHeight
    } else if height < 130 {
        throw HeightError.minHeight
    } else {
        if height >= 160 {
            return true
        } else {
            return false
        }
    }
}


//에러처리하기
//1. try
do {
    let isChecked = try checkingHeight(height: 200)
    
    if isChecked {
        print("청룡열차 가능")
    } else {
        print("후룸라이드 가능")
    }
} catch {
    print("놀이기구 타는 것 불가능")
}

//2. try? >> 옵셔널타입으로 리턴
//정상적일경우 >. 정상리턴타입으로 리턴
//에러발생시 >> nil리턴

let isChecked = try? checkingHeight(height: 200) //Bool?
//당연히 옵셔널 벗겨서 사용하기 (이프렛바인딩..)

//3. try!
//에러날수없는경우에만 사용
//정상적일경우 >> 리턴타입으로리턴
//에러 >> 런타임에러로 어플 강제종료
let isChecked2: Bool = try! checkingHeight(height: 150)





//catch블럭 처리법
//catch블럭은 do블럭에서 발생한 에러만을 처리하는 블럭

//패턴이 있는 경우
do {
    let isChecked = try checkingHeight(height: 100)
    print("놀이기구 타는 것 가능: \(isChecked)")
} catch HeightError.maxHeight { //where절 추가가능
    print("키가 커서 놀이기구 타는거 불가능")
} catch HeightError.minHeight { //<<얘 생랴하면 나머지 에러값 모두를 가르킨다 생각하면 됨
    print("키가 작아서 놀이기구 타는 것 불가능")
}


//catch패턴 없이도 처리 가능
do {
    let isChecked = try checkingHeight(height: 100)
    print("놀이기구 타는 것 가능: \(isChecked)")
} catch {
    print(error.localizedDescription)
    
    if let error = error as? HeightError { //에러타입(프로토콜)이 넘어올뿐
        switch error {
        case .maxHeight :
            print("키가 커서 놀이기구 타는 것 불가능")
        case .minHeight :
            print("키가 작아서 놀이기구 타는 것 불가능")
        }
        
    }
}


//++업데이트하면서 에러 나열?도 가능함
do {
    let isChecked = try checkingHeight(height: 100)
    print("놀이기구 타는 것 가능: \(isCheked)")
} catch HeightError.maxHeight, HeightError.minHeight {
    print("놀이기구 타는 것 불가능")
}
