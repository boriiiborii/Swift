import UIKit

//에러처리
//에러처리를 사용하는 이유
//에러가 생길때 에러처리를 하지 않는다면 어플이 강제종료될 위험있음
//에러처리를 제대로 하지 않으면 어떤에러인지 확인이 어려움

//에러처리의 과정 3단계
//1. 에러정의(enum타입, 에러프로토콜 채택 이 두가지 필수)
enum HeightError: Error {
    case maxHeight
    case minHeight
}

//2. 에러처리를 할 함수 정의 (throws, throw위치 알아놓기!)
func checkingHeight(height: Int) throws -> Bool {
    
    if height > 190 {
        throw HeightError.maxHeight
    } else if height < 130 {
        throw HeightError.minHeight
    } else {
        if height >= 160 {
            return true
        } else {
            return false
        }
    }
}


//3. 에러가 발생할 수 있는 함수처리(실행) >> do catch try키워드 유의
do {
    let isChecked = try checkingHeight(height: 200)
    print("놀이기구 타는 것 가능: \(isChecked)")
} catch {
    print("놀이기구 타는 것 불가능") // >> 에러를 던졌을때 실행하는 블럭
}
