import UIKit

//함수형프로그래밍이란?
//문제 해결을 위하여 기초적인 함수를 쓰지 않고, 조금 더 편리한(더 편리하게 쓰일 수 있도록 구체적인 구현을 하여 만든 함수)를 사용하는 프로그래밍으로 이해하였다.
//예시를 보자.



//<배열의 합을 구하시오>

//1. 명령형 프로그래밍으로 풀기
let numbers = [1, 2, 3]

var sum = 0

for number in numbers {
    sum += number
}

print(sum)

//2. 함수형 프로그래밍으로 풀기
let newNnumbers = [1, 2, 3]
var newSum = 0
//기존의 함수를 어떻게 조합해서 만들까?
newSum = newNnumbers.reduce(0) { $0 + $1 }

print(newSum)

//문제를 푸는 방식이 이렇게나 다르다.
//함수형프로그래밍은 함수를 이용해서 오류/실수가 없도록 선언형으로 프로그래밍하는것
//>> 간결한 코드작성이 가능해짐


//<배열에서 홀수만 제곱해서, 그 숫자를 다 더한 값은?>
var numbersArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

var newResult = numbersArray.filter { $0 % 2 != 0}.map { $0 * $0 }.reduce(0) { $0 + $1 }

print(newResult)
