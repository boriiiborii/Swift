import UIKit

//추가적인 고차함수
//1. forEach
//map함수와 비슷하지만 차이점이라면
//얘는 리턴값이 없기 때문에 새로운 배열로 리턴되지 않는다는것!
//클로저나 함수에서 원하는 것을 실행시켜야 한다 !
let immutableArray = [1, 2, 3, 4, 5]

immutableArray.forEach { print("숫자:\($0)") }




//2. compactMap
//nil이 포함되어 있는 배열을 가지고 compactMap을 사용시
//옵셔널 바인딩을 해주기 때문에 nil은 사라짐
//외에도 옵셔널 값도 벗겨져서 새로운 배열로 리턴한다.

let stringArray: [String?] = ["A", nil, Optional("B"), nil, "C"]

var newStringArray = stringArray.compactMap { $0 }
print(newStringArray)




//3. flatMap
//중첩된 배열을 꺼내서 새로운 배열로 리턴
var nestedArray = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(nestedArray.flatMap {$0})

//중첩이 여러번 된 배열도 가능
var newNnestedArray = [[[1,2,3], [4,5,6], [7, 8, 9]], [[10, 11], [12, 13, 14]]]

var numbersArray = newNnestedArray.flatMap { $0 }.flatMap { $0 }

print(numbersArray)
