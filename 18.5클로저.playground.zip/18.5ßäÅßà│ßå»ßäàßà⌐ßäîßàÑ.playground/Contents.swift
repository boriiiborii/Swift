import UIKit

//클로저의 캡처
var stored = 0

let closure = { (number: Int) -> Int in
    stored += number
    return stored
}

closure(3)
closure(4)
closure(5)

stored = 0
closure(5)



//캡처현상
//일반적인 함수
//함수 내에서 함수를 실행하고, 값을 리턴하는 일반적인 함수
func calcultate(number: Int) -> Int {
    
    var sum = 0
    
    func square(num: Int) -> Int {
        sum += (num * num)
        return sum
    }
    
    let result = square(num: number)
    
    return result
}

calcultate(number: 10)
calcultate(number: 20)
calcultate(number: 30)

//변수를 캡처하는 함수 중첩함수의 내부함수 캡처현상
//중첩함수로 이뤄져있고 내부함수 외부에 계속 사용하는 값이 있기 때문에 캡쳐현상이 발생
//함수/클로저를 변수에 저장하는 시점에 캡쳐 >> 클로저도 레퍼런스 타입

func calculateFunc() -> ((Int) -> Int) {
    
    var sum = 0
    
    func square(num: Int) -> Int {
        sum += (num * num)
        return sum
    }
    
    return square
}


//변수에 저자하는 경우 힙메모리에 유지
var squareFunc = calculateFunc()

squareFunc(10)
squareFunc(20)
squareFunc(30)

//변수에 저장하지 않는 경우
//calculateFunc()(10)
//이런식으로 하면 누적이 되지 않는다.

//레퍼런스타입
var dodoFunc = squareFunc
dodoFunc(20)


//이 코드는 인프런 앨런의 스위프트 문법을 참고하여 작성하였습니다.
