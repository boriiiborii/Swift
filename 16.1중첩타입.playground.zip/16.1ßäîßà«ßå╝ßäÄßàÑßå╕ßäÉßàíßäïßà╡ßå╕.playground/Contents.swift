import UIKit

//중첩타입
//타입내부에 타입을 선언하는 것은 언제나 가능

class Aclass {
    struct Bstruct {
        enum Cenum {
            case aCase
            case bCase
            
            struct Dstruct {
                
            }
        }
        var name: Cenum
    }
}


//타입 선언과 인스턴스의 생성

let aClass: Aclass = Aclass()
let bStruct: Aclass.Bstruct = Aclass.Bstruct(name: .bCase)
let cEnum: Aclass.Bstruct.Cenum = Aclass.Bstruct.Cenum.aCase
let dStruct: Aclass.Bstruct.Cenum.Dstruct = Aclass.Bstruct.Cenum.Dstruct()
//사용하는 이유
//1) 특정타입 내에서만 사용하기 위해
//타입간의 연관성을 명확히 구분하고 내부 구조를 디테일하게 설계 가능

struct BlackjackCard {
    
    enum Suit: Character {
        case spades = "♠", hearts = "♡", diamonds = "♢", clubs = "♣"
    }
    
    enum Rank: Int {
        case two = 2, three, four, five, six, seven, eight, nine, ten
        case jack, queen, king, ace //원시값 존재하지만 사용하지않고자함
        
        struct Values {
            let first: Int, second: Int?
        }
        
        //(읽기)계산속성 (열거형 내부에 저장속성은 선언 불가)
        var values: Values {
            switch self {
            case Rank.ace:
                return Values(first: 1, second: 11)
            case .jack, .queen, .king:
                return Values(first:10, second: nil)
            default:
                return Values(first: rawValue, second: nil)
            
            }
        }
    }
    //블랙잭 카드 속성/ 메서드
    //어떤 카드도 , 순서와 세트를 가짐
    let rank: Rank, suit: Suit
    
    var description: String {
        get {
            var output = "\(suit.rawValue) 세트"
            output += "숫자\(rank.values.first)"
            
            if let second = rank.values.second {
                output += "또는 \(second)"
            }
            
            return output
        }
    }
}

//A 스페이드
let card1 = BlackjackCard(rank: .ace, suit: .spades)
print("1번 카드: \(card1.description)")

//정확한 타입을 외부에서 사용하기 위해서는 중첩되어 있는 타입도 붙여야함 (명확)
let heartsSymbol: Character = BlackjackCard.Suit.hearts.rawValue

let suit = BlackjackCard.Suit.hearts



//실제 API에서 중첩 타입을 사용하는 경우 ===================
let fomatter = DateFormatter()

fomatter.dateStyle = .full
fomatter.dateStyle = DateFormatter.Style.none

//타입 확인하기 위해
let setting1: DateFormatter.Style = DateFormatter.Style.full
let setting2: DateFormatter.Style = DateFormatter.Style.medium


// Style.full     // ===> 만약에 외부에 선언되어 있다면, 실제 명확하지 않음
// Style.medium

enum Style {
    case full
    case long
    case medium
    case none
}


struct DateFormatters {
    var style: Style
}

var dateStyle1 = DateFormatters(style: .full)
dateStyle1 = DateFormatters(style: Style.full)
dateStyle1.style = Style.full
dateStyle1.style = .full

//이 코드는 인프런 앨런의 스위프트문법 강의를 참고하여 작성하였습니다.
