import UIKit

//타입으로써의 프로토콜
//프로토콜은 타입이다.
//프로토콜은 일급객체이기 때문에 타입으로 사용가능함

protocol Remote {
    func turnOn()
    func turnOff()
}

class TV: Remote {
    func turnOn() {
        print("티비켜기")
    }
    
    func turnOff() {
        print("티비끄기")
    }
}

class SetTopBox: Remote {
    func turnOn() {
        print("셋업박스켜기")
    }
    
    func turnOff() {
        print("셋업박스끄기")
    }
    
    func doNetflix() {
        print("넷플릭스 보기")
    }
}

let tv = TV()
tv.turnOn()
tv.turnOff()

let sbox = SetTopBox()
sbox.turnOn()
sbox.turnOff()
sbox.doNetflix()

//let sbox1: Remote = SetUpBox()
//sbox1.doNetflix()  >>안됨


//--------------------------------------
//프로토콜타입취급의 장점
//첫번째
let electronic: [Remote] = [tv, sbox] //프로토콜 형식으로 담김

for item in electronic { //켜기, 끄기 기능만 사용하니 타입캐스팅을 쓸 일도 없음(다만, 프로토콜에 있는 멤버만 사용 가능)
    item.turnOn()
}


//두번째
func turnOnSomeElectronics(item: Remote) {
    item.turnOn()
}

turnOnSomeElectronics(item: tv)
turnOnSomeElectronics(item: sbox)




//------------------------------
//프로토콜 준수성 검사
//is as 연산자 사용 가능
//is연산자 >> 특정 타입이 프로토콜을 채택하고 있는지 확인(참또는 거짓) / 그반대도 확인가능
//as연산자 > 타입캐스팅(특정 인스턴스 프로토콜로 변환하거나, 프로토콜을 인스턴스 실제형식으로 캐스팅)

//1) is연산자=------------
//특정타입이 프로토콜을 채택하고 있는지 확인
tv is Remote
sbox is Remote

//프로토콜 타입으로 저장된 인스턴스가 더 구체적인 타입인지 확인 가능
electronic[0] is TV
electronic[1] is SetTopBox


//2) as연산자 ---------------
let newBox = sbox as Remote
newBox.turnOn()
newBox.turnOff()

let sbox2: SetTopBox? = electronic[1] as? SetTopBox
sbox2?.doNetflix()
//(electronic[1] as? SetTopBox)?.doNetflix()


