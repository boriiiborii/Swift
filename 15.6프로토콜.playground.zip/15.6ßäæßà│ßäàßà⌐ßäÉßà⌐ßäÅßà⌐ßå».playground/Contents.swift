import UIKit

//선택적 요구사항의 구현
//어트리뷰트
//실제예시
@available(iOS 10.0, mocOS 10.12, *)
class SomeType { //"Sometype"선언은 iOS 10.0버전이상에서만 읽을 수 있음
    
}




//선택적인(구현해도되고 안해도되는)멤버선언하기
@objc protocol Remote {
    @objc optional var isOn: Bool {get set}
    func turnOn()
    func turnOff()
    @objc optional func doNetflix()
}

class TV: Remote {
    var isOn = false
    
    func turnOn() {}
    
    func turnOff() {}
}
//선택적 멤버를 선언한 프로토콜 구현시
//오브젝트씨 해당하는 클래스 전용 프로토콜임(구조체, 열거형 불가)
//오브제트씨는 구조체와 열거형에서 프로토콜 채택을 지원안함


let tv1: TV = TV()
print(tv1.isOn) //Bool타입

let tv2: Remote = TV()
print(tv2.isOn) // Bool?타입. (선택적 구현 사항이기 때문에 해당 멤버가 없으면 >> nil로 반환)
tv2.doNetflix?() // 선택적으로 선언했기 때문에, 함수가 없을 수도 있음 >> 옵션러체이닝 필요

