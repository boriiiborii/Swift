import UIKit

//self키워드의 사용(소문자)
//1) 인스턴스를 가르키기 위해 사용
class Person {
    var name: String
    init(name: String) {
        self.name = name //여기서self.name은 Person클래스의 저장속성 name을 가르킴
    }
}

//2) 새로운 값으로 속성 초기화 가능한 패턴 (값타입에서)(클래스는상속이 있어서 안됨)
struct Calculator {
    var number: Int = 0
    
    mutating func plusNumber(_ num: Int) {
        number = number + num
    }
    
    //값타입에서 인스턴스 값 자체를 치환 가능
    mutating func reset() {
        self = Calculator()  //값타입은 새로 생성해서 치환도 가능
    }
}

var cal = Calculator()
cal.number
cal.number = 10
cal.number
cal.reset()
cal.number


//3) 타입멤버에서 사용하면, 인스턴스가 아닌 타입 자체를 가르킴
struct MyStruct {
    static let club = "iOS부서"
    
    static func doPrinting() {
        print("소속은 \(self.club)입니다.")
    }
}
MyStruct.doPrinting()


//4) 타입인스턴스를 가르키는 경우에 사용 (외부에서 타입을 가르키는 경우)
class SomeClass {
    static let name = "SomeClass"
}

let myClass: SomeClass.Type = SomeClass.self //타입인스턴스란 데이터영역에있는 붕어빵틀 데이터영역에 있는 메모리구조임
//SomeClass.Type >> 메타타입

SomeClass.name
SomeClass.self.name

Int.max
Int.self.max





//-------------------------------
//Self키워드(대문자)
//1)타입을 선언하는 위치에서 사용
//2)타입속성/타입메서드를 지칭하는 자리에서 대신 사용 가능

extension Int {
    static let zero: Self = 0 //Int타입
    
    var zero: Self { // 1)타입을 선언하는 위치에 사용
        return 0
    }
    
    static func toZero() -> Self {
        return Self.zero //Int.zero
    }
    
    func toZero() -> Self {
        return self.zero // 5.zero
    }
}

Int.zero
5.zero

Int.toZero()
5.toZero()


//프로토콜에서의 Self사용 (프로토콜을 채택하는 해당 타입을 가르킴)
//이진법으로 표현된 정수에서 쓰이는 프로토콜
//프로토콜의 확장 >> 구현의 반ㅂ녹을 줄이기 위한 문법

extension BinaryInteger {
    func squared() -> Self { //타입자체(Int)를 가르킴
        return self * self //인스턴스7을 가르킴
    }
}

let x1: Int = -7
let y1: UInt = 7

if x1 <= y1 {
    print("\(x1)가 \(y1)보다 작거나 같다.")
} else {
    print("\(x1)가 \(y1)보다 크다.")
}

7.squared()

//이 코드는 인프런 앨런의 스위프트 문법을 참고하여 작성하였습니다.
