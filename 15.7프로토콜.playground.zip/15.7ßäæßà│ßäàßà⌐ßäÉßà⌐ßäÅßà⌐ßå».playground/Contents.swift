import UIKit

//프로토콜의 확장
protocol Remote {
    func turnOn()
    func turnOff()
}

//채택 >> 실제구현해야함(여러타입에서 채택한다면 반복저긍로 구현해야하는 점이 불편)

class TV1: Remote {
    //func turnOn() {print("리모컨 켜기")}
    //func turnOff() {print("리모컨 끄기)}
}

struct Aircon1: Remote {
    //func turnOn() {print("리모컨 켜기")}
    //func turnOff() {print("리모컨 끄기)}
}



//프로토콜의 확장 >> 기본(디폴트)구현 제공
//프로토콜을 채택한 모든 타입에서, 실제 구현을 계속적으로 반복해야하는 불편함을 덜기 위해
//프로토콜확장을 제공해서 메서드의 디폴트 구현을 제공함(코드의 중복 피할 수 있음)

extension Remote {
    func turnOn() {print("리모컨 켜기")}
    func turnOff() {print("리모컨 끄기")}
    
    func doAnotherAction() {
        print("리모컨 또 다른 동작")
    }
}


//프로토콜의 확장을 통한 다형성 제공 - 프로토콜 지향 프로그래밍
//클래스
class Ipad :Remote {
    func turnOn() {print("아이패드 켜기")}
    
    func doAnotherAction() {print("아이패드 다른 동작")}
}
//클래스 버츄얼테이블
//아이패드켜기, 리모컨끄기, 아이패드 또다른동작
let ipad: Ipad = Ipad()
ipad.turnOn()
ipad.turnOff()
ipad.doAnotherAction()


//프로토콜 위트니스테이블
//아이패드켜기, 리모컨끄기
let ipad2: Remote = Ipad()
ipad2.turnOn()
ipad2.turnOff()
ipad2.doAnotherAction()




//-------------------------------
//구조체
struct SmartPhone: Remote {
    func turnOn() {print("스마트폰 켜기")}
    
    func doAnotherAction() {print("스마트폰 다른 동작")}
}


//구조체 - 메서드테이블이 없음
//본래의 타입으로 인식했을때
var iphone: SmartPhone = SmartPhone()
iphone.turnOn()
iphone.turnOff()
iphone.doAnotherAction()
//스마트폰켜기, 리모컨끄기, 스마트폰 다른 동작

//프로토콜위트니스테이블 요구사항
//스마트폰켜기, 리모컨끄기

//프로토콜을 타입으로 인식했을떄
var iphone2: Remote = SmartPhone()
iphone2.turnOn()
iphone2.turnOff()
iphone2.doAnotherAction()
//스마트폰켜기, 리모컨끄기, 리모컨 또다른 동작
        

