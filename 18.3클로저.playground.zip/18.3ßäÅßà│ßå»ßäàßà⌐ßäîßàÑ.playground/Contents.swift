import UIKit

//클로저의 사용
//클로저사용이유
//1) 클로저를 파라미터로 받는 함수 정의
func closureParamFunction(closure: () -> ()) {
    print("프린트 시작")
    closure()
}

//파라미터로 사용할 함수/ 클로저를 정의
func printSwiftFunction() {
    print("프린트 종료")
}

let printSwift = { () -> () in
    print("프린트 종료")
}

//함수를 파라미터로 넣으면서 실행(그동안 배운 형태로 실행한다면)
closureParamFunction(closure: printSwiftFunction)
closureParamFunction(closure: printSwift)


//2) 함수를 실행할때 클로저 형태로 전달 (클로저를 사용하는 이유)

closureParamFunction(closure: { () -> () in
    print("프린트 종료")
}) //본래 정의된 함수를 실행시키면서, 클로저를 사후적으로 정의 가능
//활용도가 늘어남

closureParamFunction(closure: { () -> () in
    print("프린트 종료 -1")
    print("프린트 종료 -2")
})


//클로저 사용 이유 2
//1) 클로저를 파라미터로 받는 함수 정의
func closureCaseFunction(a: Int, b: Int, closure: (Int) -> Void) {
    let c = a + b
    closure(c)
}

//2) 함수를 실행할때 클로저의 형태로 전달
closureCaseFunction(a: 5, b: 2, closure: { (n) in
    print("이제 출력할게요: \(n)")
})


closureCaseFunction(a: 5, b: 2) {(number) in
    print("출력할까요? \(number)")
}

closureCaseFunction(a: 5, b: 3) { (number) in      // 사후적 정의
    print("출력")
    print("출력")
    print("출력")
    print("값: \(number)")
}

//여러가제 예시로 정확하게 이해하기
let print1 = {
    print("1")
}

let print2 = {
    print("2")
}

let print3 = {
    print("3")
}

//함수의 정의
func multiClosureFunction(closure1: () -> Void, closure2: () -> Void) {
    closure1()
    closure2()
}

//함수의 실행
multiClosureFunction(closure1: print1, closure2: print2)
multiClosureFunction(closure1: print2, closure2: print3)

multiClosureFunction(closure1: {
    print("1")
}, closure2: {
    print("2")
})

//함수의 정의
func performClosure(closure: () -> ()) {
    print("시작")
    closure()
    print("끝")
}

//함수의 실행
performClosure(closure: {
    print("중간")
})

//이 코드는 인프런 강의에 있는 앨런의 스위프트 문법을 기초하여 작성하였습니다.
