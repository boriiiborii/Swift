import UIKit

//에러를 던지는 함수를 처리하는 함수

// 에러정의
enum SomeError: Error {
    case aError
}


// 에러를 던지는 함수 정의 (무조건 에러를 던진다고 가정)
func throwingFunc() throws {
    throw SomeError.aError
}


// 에러의 처리
do {
    try throwingFunc()
} catch {
    print(error)
}
