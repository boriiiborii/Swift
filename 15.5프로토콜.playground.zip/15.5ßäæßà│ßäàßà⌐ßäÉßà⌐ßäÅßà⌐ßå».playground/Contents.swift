import UIKit

//기타프로토콜관련문법
//프로토콜은 프로토콜 간에 상속이 가능, 다중상속도 가능 (어짜피 여러가지 요구사항의 나열일 뿐)
protocol Remote {
    func turnOn()
    func turnOff()
}

protocol AirConRemote {
    func Up()
    func Down()
}

protocol SuperRemoteProtocol: Remote, AirConRemote { //프로토콜끼리, 상속 구조를 만드는것이 가능
    //func turOn()
    //func turnOff()
    //func Up()
    //func Down()
    
    func doSomething()
}



//-----------------------------------------
//클래스 전용 프로토콜 (AnyObject)
protocol SomeProtocol: AnyObject {
    func doSomething()
}

//구조체는 채택할 수 없게 됨
//struct AStruct: SomeProtocol {
//
//}

//클래스에서만 채택 가능
class AClass: SomeProtocol {
    func doSomething() {
            print("Do something")
    }
}




//-------------------------------------
//프로토콜 합성문법
//프로토쾔을 합성하여 임시타입으로 활용 가능
protocol Named {
    var name: String {get}
}

protocol Aged {
    var age: Int {get}
}

//하나의 타입에서 여러개의 프로토콜을 채택하는 것이 당연히 가능(다중 상속과 비슷한 역할)

struct Person: Named, Aged {
    var name: String
    var age: Int
}

//프로토콜을 두개 병합해서 사용하는 문법은 &로 연결
func wishHappyBirthday(to celebrator: Named & Aged) { //임시적인 타입으로 인식
    print("생일축하해, \(celebrator.name), 넌 이제 \(celebrator.age)살이 되었구나!")
}

let birthdayPerson = Person(name: "홍길동", age: 20)
wishHappyBirthday(to: birthdayPerson)

let whoIsThis: Named & Aged = birthdayPerson //임시적인 타입으로 저장 (두개의 프로토콜을 모두 채택한 타입만 저장 가능)
