import UIKit

//고차함수종류
//(대표적)map, filter, reduce
//(추가적)forEach, compactMap, flatMap

//고차원 함수 >> 배열.고차원함수(파라미터는함수/클로저)
//기본적으론 배열다음에 고차원함수를 많이 씀. 외엔 딕셔너리, 세트에도 쓰인다고 함



//1. map함수
//각 아이템을 맵핑해서 맵핑한 결과를 배열에 담는 형태
let numbers = [1, 2, 3, 4, 5]

var newNumbers = numbers.map { ("숫자: \($0)") }
print(newNumbers)

//숫자 뿐만 아니라 스트링탕입의 배열도 (아닌 모든 타입 전부 다 ) 가능하다
var alphabet = ["A", "B", "C", "D"]
var newAlphabet = alphabet.map({ "My name is \($0)"})
print(newAlphabet)




//2. filter함수
//기존 배열에서 필터 말 그대로 특정 단어가 포함되어있는 아이템을 추출하여 새로운 배열로 리턴
//필터링한다고 생각하면 됨
//문자열에선 contains함수와 자주 쓰이는 것 같음
let names = ["Apple", "Banana", "Circle", "Dream", "Blue"]
var newNames = names.filter { name in
    return name.contains("B")
}
print(newNames)

let array = [1, 2, 3, 4, 5, 6, 7, 8]
var evenNumberArray = array.filter {$0 % 2 == 0}
print(evenNumberArray)

//이때까지 사용 했듯 클로저 형태로 고차함수를 사용하는것이 일반적이지만, 클로저 자리에 함수를 호출할수도 있음 (참고)




//3. reduce
//초기값이 있고, 조건에 맞게 결합하여 마지막의 결과값을 리턴하는 함수
var numbersArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
var resultSum = numbersArray.reduce(0) { sum, num in // sum은 누적값, num은 그 순서의 아이템
    return sum + num
}
print(resultSum)





//고차배열 혼합해서 사용하기
numbersArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
//홀수만 제곱해서, 그 숫자를 다 더한값은?
var newResult = numbersArray.filter { $0 % 2 != 0 }.map { $0 * $0 }.reduce(0) { $0 + $1 }
print(newResult)
