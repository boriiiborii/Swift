import UIKit

// 함수와 클로저 형태 비교
//함수의 형태
func add(a: Int, b: Int) -> Int {
    let result = a + b
    return result
}

//클로저 형태
let _ = {(a: Int, b: Int) -> Int in
    let result = a + b
    return result
}

//클로저의 형태(타입추론 가능경우)
//let _: (Int, Int) -> Int = {(a,b) in
//      let result = a + b
//      return result
//}

//클로저의 형태
//가장 많이 사용하는 형태: 리턴형에 대한 표기를 생략 가능
let aClosure1 = {(str: String) in
    return "Hello, \(str)"
}

let aClosure2: (String) -> String = { (str) in
    return "Hello, \(str)"
}

let aClosure3 = {
    print("This is a closure.")
}

//파라미터타입의 생략도 대부분 가능하다.
let closureType4 = { str in //컴파일러가 타입추론 가능한 경우 생략 가능하다.
    return str + "!"
}
