import UIKit

//클로저 문법 최적화
//클로저는 실제 사용시 읽기쉽고, 간결한 코드 작성을 위해 축약된 형태의 문법을 제공함


//1. 트레일링클로저 (후행클로저문법)
//1) 클로저를 파라미터로 받는 함수 정의
func closureParamFunction(closure: () -> Void) {
    print("프린트 시작")
    closure()
}

//2)함수를 실행할때 클로저 형태로 전달
//함수 마지막 전달인자로 클로저 전달되는 경우, 소괄호 생략
closureParamFunction {
    print("프린트 종료")
}

//연습
func closureCaseFuntion(a: Int, b: Int, closure: (Int) -> Void) {
    let c = a + b
    closure(c)
}

closureCaseFunction(a: 5, b: 2) { number in //소괄호가 클로저 앞에서 닫힘
    print("출력할까요? \(number)")
}




//2.파라미터 및 생략등의 간소화
func performClosure(param: (String) -> Int) {
    param("Swift")
}

performClosure { $0.count} // 첫번째파라미터의 글자수를 센다.


//축약형태로의 활용
let closureType1 = { (param) in
    return param % 2 == 0
}

let closureType2 = { $0 % 2 == 0}


let closusreType3 = { (a: Int, b: Int) -> Int in
    return a * b
}

let closureType4: (Int, Int) -> Int = { (a,b) in
    return a * b
}

let closureType5: (Int, Int) -> Int = { $0 * $1 }




//콜백함수: 함수를 실행하면서, 파라미터로 전달하는 함수
//주로 함수가 실행된 결과는 콜백함수로 전달받아 처리하기 때문에

//여러개의 함수를 파라미터로 사용할때
func multipleClosure(first: () -> (), second: () -> (), third: () -> ()) {
    first()
    second()
    third()
}

//기존방식에는 마지막으로 클로저만 트레일링 클로저로 쓸 수 있었음
//하지만 지금은 모든 클로저를 트레일링 클로저로 사용할 수 있음
multipleClosure {
    print("1")
} second: {
    print("2")
} third: {
    print("3")
}


//아규먼트레이블을 생략하는 경우
func multipleClosure2(first: () -> () , _ second: () -> (), third: () -> ()) {
    first()
    second()
    third()
}

//아규먼트 레이블을 생략하지 못함
multipleClosure2 {
    print("1")
} _: {
    print("2")
} third: {
    print("3")
}




//이 코드는 인프런 앨런의 스위프트 문법을 참고하여 작성하였습니다.
